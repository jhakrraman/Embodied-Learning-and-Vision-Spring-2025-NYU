from nautilus_launcher import launch

# Launcher for internal use.
# Source: https://github.com/nicklashansen/nautilus-launcher

if __name__ == '__main__':
    launch()
